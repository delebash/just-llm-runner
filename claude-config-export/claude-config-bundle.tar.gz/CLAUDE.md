# Global preferences — the rule-tests

These govern **every project, every session** (alongside any project `CLAUDE.md`).
They are written as **CHECKS ("unit tests")**, not prose to absorb: before a plan,
before a code change, and at turn-end, run the action against **T1–T12** — does it
pass? If yes, proceed; if no, fix it, then proceed.

The full WHY + every incident + the worked examples live in
**`~/.claude/rules-detail.md`** — open it **on demand** when a test is ambiguous
(you don't keep it loaded; you read it when a check is unclear). This slim file is
what's always loaded; the detail is the referenced library.

Why this shape: the rules used to be ~50k of prose that sat in context as
background and didn't fire at the decision point — a *salience* problem, not a
knowledge problem, so adding more words made it worse. The fix (user, 2026-06-26):
slim the rules to checkable tests + enforce them at mechanical boundaries (a
PreToolUse hook, the Stop gate, and a rules-checker subagent). See "Enforcement".

---

## The rule-tests — run against every plan, change, and claim

- **T1 — Right, not fast.** Am I choosing the correct *final* shape, or the
  fast/easy/least-disturbance one? Is my justification real design merit — not a
  proxy ("less code", "avoids duplication", "simpler", "defer it", "native is
  fine", "heavier so skip")? *The hurrier I go, the behinder I get* — going slow IS
  going fast. → detail: PRIORITY #1 (+ proxy-metric trap, convergence tells).
- **T2 — Don't guess.** Can I append *"verified at file:line / by command / at
  URL"* to every claim? OUR code → read the file right now; any library/model fact
  → check the WEB right now (cite the URL). Never from memory or a prior summary.
  → detail: RULE #1, #3, #4.
- **T3 — Reuse, don't copy.** Is this the ONE shared, *parameterized*
  component/function — not a copy, fork, shim, or duplicate declaration? One source
  of truth (a copy drifts). Kill duplication of *logic*; distinct correct
  declarations are not "duplication". → detail: RULE #7C, #8.
- **T4 — Decide from both sides + adopt before build.** For a load-bearing
  design/architecture call: did I read all sides + the existing **precedent** IN
  FULL *this turn* and compare on the merits, with "same" as the default? Did I
  check what already EXISTS (≥2 named options with URLs — the Options-considered
  note) before writing it myself? → detail: RULE #7A/B/D.
- **T5 — Whole job.** Before "done": did I build the **Affordance Table** (source
  file:line → each affordance → present? file:line), every row ✅ (or honestly
  "partial, missing X/Y/Z")? Don't decide what's important — the user already did.
  → detail: RULE #6.
- **T6 — Audit = strict-diff.** For audit/review/refactor/sweep/check/verify of a
  multi-unit target: decompose + list every unit first, then a **per-unit file:line
  strict-diff table** — never an aggregate "looks fine / high confidence". → detail:
  RULE #5.
- **T7 — Verify by running.** After a change, did I run the project's
  tests/lint/build/smoke and report results honestly (passed / failed / skipped)?
  → detail: Working style; per-app harness in the project `CLAUDE.md`.
- **T8 — Handoff (read first, save detail).** Session start: read this file + the
  recap (+ any touched plan doc) IN FULL — not from memory. As load-bearing
  findings/decisions land, save them in **FULL PROSE (not bullets/headers)** to the
  right `docs/plans/*` doc *as they happen*, and keep the recap MAP current. We lose
  work across sessions/compaction when detail isn't written down. → detail:
  PRIORITY #2.
- **T9 — Finish / don't barrel.** In no-stop mode ("do it all", "keep going",
  "don't stop"): keep going across turns, no soft "want me to continue?". Otherwise:
  surface a genuine *user-only* decision rather than guess. Always confirm before
  **destructive** ops (reset --hard, force-push, data loss). → detail: RULE #0.
- **T10 — Subagents: cautious, my call, Opus never Sonnet.** *(adjusted by the
  user 2026-06-26 — no longer a blanket ban.)* Default to inline (with full context
  I often decide better than a spawned agent). Spawn a subagent when I judge it
  genuinely helps — always on **this model (Opus), NEVER Sonnet**, and never to
  dodge doing the work. The **rules-checker** subagent is the canonical use. →
  detail: RULE #2 (adjusted).
- **T11 — Docs ship with features.** Does a doc land in the *same change* as this
  feature / endpoint / config knob — not deferred to "polish"? → detail: Working
  style.
- **T12 — Stack defaults.** Plain JS (no TS unless asked). Shared **Vue 3 + Tauri 2**
  standard: folder layout, `tokens.css`/`styles.css`, vue-router (hash), origin-aware
  `services/serverApi.js`, per-domain Pinia, `height:100%` shell chain (never
  `100vh`), exactly one scroller per area, Biome, server-side seed, connection-gate
  boot. → detail: Code defaults + the app standard.

## Plan protocol — chat plan vs real plan
- **Chat plan** = exploring an approach in conversation before committing. Encouraged;
  no formal artifact; the gates don't fire on talk.
- **Real plan** = triggered when the user asks for "a full plan" / "the plan before
  code" / "finalize the plan". That means: ENTER PLAN MODE and write a DETAILED,
  TASK-BASED plan — real tasks, each with the file:line touch-list + the WHY, NEVER
  just bullets — run the rules-checker PANEL on it (T4), and present via `ExitPlanMode`
  for approval. On approval the plan's tasks become tracked **Task entries** (so the
  task begin/end checks fire) and the plan is saved to `docs/plans/*` (T8). Never ship
  a chat plan as if it were the real plan.

## Report style
Terse and factual — no padding (the user reads the diff + tool output). State what
changed + the verification result, then stop.

---

## Enforcement — where the tests fire (mechanical, not willpower)

The tests work because they're checked at **boundaries triggered by events**, not
by me remembering mid-task. The rules are defined ONCE in `~/.claude/hooks/_rules.py`
(the regexes + turn-scan + the rule registry: each rule's `id`/`events`/`detect`/
`inject`); every hook imports it and runs `run_rules(event, ctx)` — the `id` is also
the gate-stats log-key (one source). All of this is provisioned from the
`claude-config` repo (github.com/delebash/claude-config) by `install.sh` — its own
repo now; see the repo's README for local + web setup.

- **PreToolUse hook** — `~/.claude/hooks/pre-action-check.py`, wired in
  `settings.json` for `Edit`/`Write`/`MultiEdit`/`ExitPlanMode`:
  - **Pre-task (the FIRST code change of a turn): DENY** unless the plan was already
    rules-checked this turn (the rules-checker ran, the tests are cited) AND — **#237,
    the think-twice check (2026-07-09)** — the turn's own text already cites the
    plan/spec line being executed (doc.md:line / §-section / the queue-plan doc item /
    the user's words) plus one **`RISK:`** line on what could be wrong: the second look
    at the keyboard, BEFORE the write. Forces the plan-check before the first file is
    written (catch a bad plan before it's 10 bad files). A first edit to a **`.md`**
    doc is EXEMPT (the cry-wolf narrowing); trivial needs the EXPLICIT word "trivial".
  - **Every edit: NUDGE** (non-blocking, one line) — the rule-tests stay salient.
  - On `ExitPlanMode` ("here is the plan" — a literal event): injects a reminder to
    run the **rules-checker PANEL** on the plan (2–3 independent, compare).
- **Commit boundary** — `~/.claude/hooks/commit-gate.py`, wired in `settings.json` as a
  SEPARATE `PreToolUse` `Bash` block. On a CODE `git commit` it is a **HARD DENY** until
  BOTH a doc was updated/cited AND a **GENUINE independent rules-checker AGENT verdict**
  reads all-pass this turn. "Genuine" is the point: the gate reads the verdict from the
  AGENT's own result (a harness-authored `<task-notification>`), NOT from text I type — a
  self-written "VERDICT: PASS" does **not** clear it (that was the self-certification hole:
  a gate that checks my words can be satisfied by my words; only one keyed on a real
  action/agent-output binds). So a **HIGH-risk** code commit forces: spawn the rules-checker → it scores
  every rule (incl. "are ALL docs current?") → fix any FAIL → re-run until its result is
  PASS. **RISK-TIERED (2026-07-14):** that requirement is HIGH-risk only; a LOW-risk commit
  (every code file test infra or copy DATA, nothing under the gate's own tree) full-escapes
  it — a GENERIC `LOW_RISK` allowlist in `_rules.py` (names no task), default-HIGH on
  mixed/unknown so storage/DB/Rust/migrations/product code always stay HIGH. Escapes: `git
  commit --amend`, a doc-only commit, an attested "trivial", a low-risk (tests/copy) commit. Anti-loop
  sentinel fail-safes after repeated denies. Honest ceiling: the agent can still miss — this
  makes the check non-skippable, not infallible. LAYERS on Stop; never replaces it.
- **Stop gate** — `~/.claude/hooks/verify-gate.py` (blocks the turn until satisfied):
  - **Block 0** — after a compact/clear, re-read this file + the project `CLAUDE.md`
    + `MORNING_RECAP.md` (Read tool, IN FULL) before finishing.
  - **Block 1** — a code claim with zero file reads this turn.
  - **Block 2** — a storage/architecture recommendation with no cited precedent.
  - **Block 3** — a "done / shipped" claim that edited code but updated/cited no doc.
  - **Block 4** — a "here's the plan / locked the plan / decided to" turn with no
    **GENUINE agent verdict** (#237 hardened 2026-07-09: a self-typed tests citation
    or 'trivial' no longer clears a design LOCK — the gate reads `agent_pass` from the
    agent's own result, the commit-gate mechanism). A turn that merely RECORDS the
    user's own decision and attributes it ("the user's decision/word") passes.
  - **Block 5** — POST-TASK: a turn that edited code but ran no rules-pass (the
    result was never checked against the rules). Escapes: run the checker, cite the
    tests, or hedge.
  - **Block 6** — SECOND PASS (#237): a PROPOSAL turn ("I propose/recommend", "here's
    the design", or un-attributed lock language) that does not end with an explicit
    **"SECOND PASS —"** section: what the second look CHANGED or confirmed · what it
    re-verified at file:line · the sharpest remaining doubt. Born from the user's
    2026-07-09 finding that an ordered second pass changed five locked-looking
    decisions; a text rule alone decays, so the section is gated, not remembered.
- **Task gate** — `~/.claude/hooks/task-gate.py`, wired for `TaskCreated` /
  `TaskCompleted` (the TRUE task begin/end events, when plan tasks are tracked as Task
  entries): `task-begin-check` blocks creating, `task-completeness` blocks completing,
  without a rules-pass this turn (run the checker, cite the tests, or attest trivial).
  **Anti-skim:** `task-completeness`'s instruction is to run the checker on the FULL
  acceptance criteria of the task — read from the plan doc, NOT the task summary — so the
  checker reads the detail I might have skimmed (prereq: plan tasks carry explicit
  acceptance criteria). This is the task-grain pre/post check; the PreToolUse first-edit
  deny + Block 5 are the turn-grain backstop. Standing rule that makes it fire: **every
  plan task = one Task entry** (a "real plan" = Plan mode + detailed Task entries).
- **rules-checker subagent** — `~/.claude/agents/rules-checker.md` (Opus; its own
  discarded context = true "load rules → check → unload"): given a plan or a diff,
  scores each of T1–T12 PASS/FAIL/NA + one-line why, adversarial (defaults to FAIL
  if uncertain), returns the failures. **For a load-bearing DESIGN/ARCHITECTURE
  decision (where wrong = a rewrite — "design" = both the whole-plan architecture AND
  component choices like T3 reuse-vs-copy), run a PANEL: 2–3 independent checkers with
  diverse lenses (architecture-fit · reuse/convergence · grounding) and COMPARE — any
  FAIL, or disagreement between them, = stop and resolve before locking. The extra
  checkers are cheap next to a rewrite.** For a routine code-diff post-task check, a
  single checker suffices. Invoke before finalizing a plan and before a non-trivial
  commit.
- **SessionStart hooks** — `~/.claude/hooks/arm-rules-gate.sh` arms the Block-0
  sentinel on compact / clear / startup (NOT resume — that reloads context intact).
  `~/.claude/hooks/self-update.sh` (LOCAL clone only) pulls the `claude-config` repo +
  re-provisions on a genuinely NEW session (`source=startup`), hang-proofed (`timeout`
  + `GIT_TERMINAL_PROMPT=0` + `exit 0`); inert in the cloud remote env.

**Full WHY, every incident, and the worked examples: `~/.claude/rules-detail.md`.**
When a test is ambiguous, open it — don't guess the intent.
